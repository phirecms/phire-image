<?php

namespace Phire\Image\Model;

use Phire\Model\AbstractModel;

class Image extends AbstractModel
{

}
