<?php

return [
    'image-editor' => [
        'index'
    ]
];